from flask import Flask, render_template, request
import os
import cv2
import json
import sqlite3

app = Flask(__name__)
UPLOAD_FOLDER = 'uploaded'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs("uploaded", exist_ok=True)
os.makedirs("answer_keys", exist_ok=True)

# Bubble detection
def detect_bubbles(image_path):
    img = cv2.imread(image_path, 0)
    if img is None:
        raise ValueError("Image not found or unreadable.")
    blurred = cv2.GaussianBlur(img, (7, 7), 0)
    _, thresh = cv2.threshold(blurred, 120, 255, cv2.THRESH_BINARY_INV)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    bubbles = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if 250 < area < 600:
            x, y, w, h = cv2.boundingRect(cnt)
            bubbles.append((x, y, w, h))
    bubbles = sorted(bubbles, key=lambda b: (b[0], b[1]))  # left to right, then top to bottom
    return bubbles

# Bubble fill check
def is_marked(img, bubble):
    x, y, w, h = bubble
    roi = img[y:y+h, x:x+w]
    filled_pixels = cv2.countNonZero(roi)
    total_pixels = roi.size
    fill_ratio = filled_pixels / total_pixels
    return fill_ratio > 0.5

# Map bubbles to questions
def map_bubbles_to_questions(bubbles):
    question_map = {}
    group_size = 5
    for i in range(0, len(bubbles), group_size):
        q_no = (i // group_size) + 1
        options = ['A', 'B', 'C', 'D', 'E']
        vertical_group = sorted(bubbles[i:i+group_size], key=lambda b: b[1])
        question_map[q_no] = dict(zip(options, vertical_group))
    return question_map

# Get marked answers
def get_marked_answers(img, question_map):
    marked = {}
    for q_no, options in question_map.items():
        for opt, bubble in options.items():
            if is_marked(img, bubble):
                marked[q_no] = opt
                break
    return marked

# Load answer key
def load_answer_key(set_name):
    path = f"answer_keys/{set_name}.json"
    with open(path, "r") as f:
        return json.load(f)

# Evaluate answers
def evaluate_answers(marked_answers, answer_key):
    score = 0
    subject_scores = {}
    for subject, answers in answer_key.items():
        correct = 0
        for q_no, correct_opt in answers.items():
            try:
                q_no_int = int(q_no)
                if q_no_int in marked_answers and marked_answers[q_no_int].upper() == correct_opt.upper():
                    correct += 1
            except Exception as e:
                print(f"⚠ Error comparing Q{q_no}: {e}")
        subject_scores[subject] = correct
        score += correct
    return score, subject_scores

# Save result
def save_result(student_id, score):
    conn = sqlite3.connect("results.db")
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS results (
                        student_id TEXT,
                        score INTEGER)''')
    cursor.execute("INSERT INTO results VALUES (?, ?)", (student_id, score))
    conn.commit()
    conn.close()

# Flask routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['omr_sheet']
    student_name = request.form.get("student_name", "Unknown Student")
    filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filename)

    img = cv2.imread(filename, 0)
    bubbles = detect_bubbles(filename)
    question_map = map_bubbles_to_questions(bubbles)
    marked_answers = get_marked_answers(img, question_map)
    answer_key = load_answer_key("set_a")
    score, subject_scores = evaluate_answers(marked_answers, answer_key)

    save_result(student_name, score)

    return render_template('result.html', name=student_name, score=score, subjects=subject_scores)

if __name__ == '__main__':
    print("✅ Flask app is starting...")
    app.run(debug=True)